#!/bin/sh
set -v

mkdir -p $HOME/.gnome2/gedit/styles
cp ./*.xml $HOME/.gnome2/gedit/styles/.
